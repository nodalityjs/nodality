

import { Theme } from "../lib/theme.js";

// 22/08/2020 - 16:30
class Animator {
    
    constructor(){
         this.state = {
           isExpanded: false,
             isMovedUp: false,
              isMovedDown: false
        }

		this.openedElements = new WeakMap();

		// Auto-subscribe every component to Theme so dark-mode "just works"
		// even when the user never declared a per-component theme map.
		// Subclasses set this.res later in their own constructor; we re-apply
		// in a microtask, by which time the synchronous chain has finished.
		if (typeof document !== "undefined") {
			this._themeUnsub = Theme.subscribe((mode) => this._applyTheme(mode));
			Promise.resolve().then(() => this._applyTheme(Theme.mode));
		}
    }

	isHidden(hide){
		if (hide){
			this.res.style.display = "none";
		}
	}

	// Nodality dark-mode hook.
	// Usage: .theme({ light: {color: "#111", background: "#fff"},
	//                 dark:  {color: "#eee", background: "#111"} })
	// Or:    .set({ theme: {...same shape...} })
	// Listens for "nodality:theme" events on document and re-applies inline styles.
	theme(map){
		if (!map || typeof map !== "object") return this;
		this._themeMap = map;
		this._applyTheme(Theme.mode);
		if (!this._themeUnsub) {
			this._themeUnsub = Theme.subscribe((mode) => this._applyTheme(mode));
		}
		return this;
	}

	// Tear down theme subscription. Call this when removing a component from
	// the DOM in long-lived apps to prevent listener accumulation on document.
	destroy(){
		if (typeof this._themeUnsub === "function") {
			this._themeUnsub();
			this._themeUnsub = null;
		}
		if (this.res && this.res.parentNode) {
			this.res.parentNode.removeChild(this.res);
		}
		return this;
	}

	_applyTheme(mode){
		if (this._noTheme || !this.res) return;

		// Explicit per-component map wins outright.
		if (this._themeMap) {
			const styles = this._themeMap[mode];
			if (!styles) return;
			for (const k in styles) {
				this.res.style[k] = styles[k];
			}
			return;
		}

		// Fallback: Theme.defaults. Only fill in properties the user hasn't
		// already set inline, so user styles always win.
		//
		// Snapshot is taken lazily, per-key, the first time each key shows up
		// in Theme.defaults. This matters because Theme.setDefaults() can be
		// called AFTER components are constructed; when a new key appears we
		// capture the current inline style (which still reflects what the
		// user set in .set({...})) before applying any default.
		const defaults = Theme.defaults && Theme.defaults[mode];
		if (!defaults) return;
		if (!this._themeOriginal) this._themeOriginal = {};
		for (const k in defaults) {
			if (!(k in this._themeOriginal)) {
				this._themeOriginal[k] = this.res.style[k] || "";
			}
			if (this._themeOriginal[k]) continue; // user set this — never touch
			this.res.style[k] = defaults[k];
		}
	}

	keySet(obj){
		this.temporaryVal = 1;
		if (Array.isArray(obj)) {
			for (let i = 0; i < obj.length; i++) {
				if (obj[i] && obj[i].key != null) {
					this.res.style[obj[i].key] = obj[i].value;
				}
			}
			return this;
		}
		this.res.style[obj.key] = obj.value;
		return this;
	}

	// 08/10/2025

	/*
	id (in super class)
	pad, mar
	respad, resmar
	resprop, hover
	exact, zIndex,
	position, top,
	hover, size,
	width, maxWidth,
	height, maxHeight,

	*/
		commonMethods(obj){ // define in anim
		/*	obj.pad && this.pad(obj.pad);
			obj.mar && this.mar(obj.mar);
			obj.respad && this.respad(obj.respad);
			obj.resmar && this.resmar(obj.resmar);
			obj.exact && (this.res.style.fontSize = obj.exact);
			obj.zIndex && (this.res.style.zIndex = obj.zIndex);
			obj.position && (this.res.style.position = obj.position);
			obj.top && (this.res.style.top = obj.top);
			obj.hover && this.hover(obj.hover);
			obj.size && this.fluidCopy(obj.size);
			obj.cursor && (this.res.style.cursor = obj.cursor);
			// width xx, height xx, background xx, radius xx, resprop xx, keySet, maxHeight xx, maxWidth xx

			obj.width && (this.res.style.width = obj.width);
			obj.maxWidth && (this.res.style.maxWidth = obj.maxWidth);

			obj.height && (this.res.style.height = obj.height);
			obj.maxHeight && (this.res.style.maxHeight = obj.maxHeight);

			

			obj.background && (this.res.style.background = obj.background);

			obj.resprop && this.resprop(obj.resprop);

			obj.keySet && this.keySet(obj.keySet);

			// weight, bold, font, hide, radus, lineHeight

			obj.weight && (this.res.style.fontWeight = obj.weight);

			obj.bold && (this.res.style.fontWeight = "bold");

			obj.font && (this.res.style.fontFamily = obj.font);

			obj.hide && this.isHidden(obj.hide);

			obj.radius && (this.res.style.borderRadius = obj.radius);

			obj.lineHeight && (this.res.style.lineHeight = obj.lineHeight);
*/

  // Map of obj keys → style properties
  // Extended 2026-04-27 — first-class CSS props so callers don't need keySet.
  // Categories: positioning, flex-item, grid, typography, shadows/effects,
  // overflow, sizing, pointer/selection.
    const styleMap = {
        // ── Typography / sizing (pre-existing) ─────────────────────────
        exact: "fontSize",
        cursor: "cursor",
        width: "width",
        maxWidth: "maxWidth",
        height: "height",
        maxHeight: "maxHeight",
        radius: "borderRadius",
        lineHeight: "lineHeight",
        background: "background",
        font: "fontFamily",
        opacity: "opacity",
        gap: "gap",
        minHeight: "minHeight",

        // ── Positioning ────────────────────────────────────────────────
        position: "position",
        inset: "inset",
        top: "top",
        right: "right",
        bottom: "bottom",
        left: "left",
        zIndex: "zIndex",

        // ── Flex item / wrapping ───────────────────────────────────────
        flex: "flex",
        flexShrink: "flexShrink",
        flexGrow: "flexGrow",
        flexBasis: "flexBasis",
        flexWrap: "flexWrap",
        alignSelf: "alignSelf",
        // `display` accepts any value: "inline-flex", "grid", "block", etc.
        display: "display",

        // ── Grid ───────────────────────────────────────────────────────
        gridTemplateColumns: "gridTemplateColumns",
        gridTemplateRows: "gridTemplateRows",
        rowGap: "rowGap",
        columnGap: "columnGap",

        // ── Typography (extended) ──────────────────────────────────────
        letterSpacing: "letterSpacing",
        textTransform: "textTransform",
        whiteSpace: "whiteSpace",
        // Wrapping behaviour for long words. `overflowWrap: "break-word"` (or
        // "anywhere") lets a label that's longer than its flex-shrunken cell
        // break mid-word instead of overflowing horizontally.
        overflowWrap: "overflowWrap",
        wordBreak: "wordBreak",
        wordWrap: "wordWrap",

        // ── Shadows / effects ──────────────────────────────────────────
        boxShadow: "boxShadow",
        backdropFilter: "backdropFilter",
        WebkitBackdropFilter: "WebkitBackdropFilter",

        // ── Overflow ───────────────────────────────────────────────────
        overflow: "overflow",
        overflowX: "overflowX",
        overflowY: "overflowY",
        WebkitOverflowScrolling: "WebkitOverflowScrolling",
        WebkitTapHighlightColor: "WebkitTapHighlightColor",

        // ── Sizing (extended) ──────────────────────────────────────────
        minWidth: "minWidth",
        boxSizing: "boxSizing",

        // ── Pointer / selection ────────────────────────────────────────
        pointerEvents: "pointerEvents",
        userSelect: "userSelect",
        WebkitUserSelect: "WebkitUserSelect",

        // ── Convenience extras ─────────────────────────────────────────
        // textAlign here lets non-Text classes (Wrapper, FlexRow) align
        // child text without falling through to keySet. Text already
        // exposes `align` separately.
        textAlign: "textAlign",
        transition: "transition",
    };

    // Apply styles safely
    for (const key in styleMap) {
        if (obj[key] != null) {
            this.res.style[styleMap[key]] = obj[key];
        }
    }

    // `transform` is overloaded: a string is a plain CSS transform, an
    // object is a Nodality animation descriptor handled by reactOnTransform
    // (called further below). Strings are applied here so they reach the
    // DOM without going through the animation system.
    if (typeof obj.transform === "string") {
        this.res.style.transform = obj.transform;
    }
//alert(obj.respad);
    // Special methods
    obj.pad && this.pad(obj.pad);
    obj.mar && this.mar(obj.mar);
    obj.respad && this.respad(obj.respad);
    obj.resmar && this.resmar(obj.resmar);
    obj.hover && this.hover(obj.hover);
    obj.size && this.fluidCopy(obj.size);
    obj.resprop && this.resprop(obj.resprop, obj);
    obj.keySet && this.keySet(obj.keySet);
    obj.noTheme && (this._noTheme = true);
    obj.theme && this.theme(obj.theme);
    obj.hide && this.isHidden(obj.hide);
	// Only route to the animation system for object-shaped transforms.
	// String transforms are applied above via the styleMap path.
	(obj.transform && typeof obj.transform === "object") && this.reactOnTransform(obj.transform);

	(obj.opacity !== undefined) && (this.res.style.opacity = obj.opacity);

    // Font weight handling
    if (obj.bold) {
        this.res.style.fontWeight = "bold";
    } else if (obj.weight != null) {
        this.res.style.fontWeight = obj.weight;
    }

	

			return this;
	}

	 hover(obj){
		


		if (obj.border){
			//alert("IHO")
			// // console.log("BORDERA IS ");
			// // console.log(obj.border);

			let w = obj.border.width;
			this.res.style.border = w ? `${w}px solid transparent` : "1px solid transparent";

			//this.res.style.border = "1px solid transparent";
		}


		let bops = this.options && this.options.borderObj;

		if (bops){
			//alert("PP")
			this.res.style.border = `${bops.width}px solid ${bops.color}`;
		}
		
        this.prevColor = this.res.style.backgroundColor;
		this.foreColor = this.res.style.color;
		this.prevBorder = this.res.style.border;
		this.prevBoxShadow = this.res.style.boxShadow;


	/*	if (obj.border){
			//this.res.style.border = `1px solid transparent`;
			if (obj.borderObj && obj.borderObj.width){ // fix here

				let w = this.options.borderObj.width ?? 3;
				this.res.style.border = `${w}px solid transparent`;
				
			} else {
				// 14:53:15 this was stupid
				//this.res.style.border = `1px solid transparent`;
			
			
			}
			
		}*/
  

	
		if (obj.animation) {

			this.res.style.transition = `${obj.animation}`; //`${obj.animation}s ease-in-out`; // stop resize ???
			this.res.style.transionProperty = `background, color, transform`;
			//  this.transition(obj.animation);
		}

		// remember the pre-hover transform so scale-on-hover can be undone cleanly
		this.prevTransform = this.res.style.transform;

        this.res.onmouseout = () => {
		//	alert("OJHOIH")
			this.res.style.backgroundColor = `${this.prevColor}`;
			this.res.style.color = `${this.foreColor}`;
		    this.res.style.border = this.prevBorder;
		    if (obj.scale != null || obj.transform != null) {
		        this.res.style.transform = this.prevTransform || "";
		    }
		    if (obj.boxShadow != null) {
		        this.res.style.boxShadow = this.prevBoxShadow || "";
		    }


		/*	if (obj.borderObj && obj.borderObj.width){

				let w = this.options.borderObj.width ?? 3;
				this.res.style.border = `${w}px solid transparent`;
				
			} else {
				//this.res.style.border = `1px solid transparent`;
			}*/


			/*if (obj.border){
				this.res.style.border = "1px solid transparent";
			}*/
			
			
			
			// // // console.log(`OUT: ${this.res.style.backgroundColor}`);
		}
        
        this.res.onmouseover = () => {
			//this.res.style.backgroundColor = "#ffffff"; //obj.background; //`#ffffff`;
			//alert("OJHOIH")
		//	alert(obj.background);
			this.res.style.color = obj.color;
			this.res.style.backgroundColor = obj.background;

			if (obj.border){
				//alert("IHO")

				let w = obj.border.width;
				let color = obj.border.color ?? "#2ECC71";
				//console.log("WO", w, color);
				//alert(obj.border.color);
				this.res.style.border = w ? `${w}px solid ${color}` : "1px solid #2ECC71";
			}

			if (obj.scale != null || obj.transform != null) {
				const base = this.prevTransform ? `${this.prevTransform} ` : "";
				const parts = [];
				if (obj.transform != null) parts.push(obj.transform);
				if (obj.scale != null) parts.push(`scale(${obj.scale})`);
				this.res.style.transform = `${base}${parts.join(" ")}`;
			}

			if (obj.boxShadow != null) {
				this.res.style.boxShadow = obj.boxShadow;
			}

			//if (this.options && this.options.borderObj){ was here
				
				//let o = this.options.borderObj;
				//this.res.style.border = `${o.width}px solid ${o.color}`;
				//this.res.style.borderRadius = `${o.radius}`;
			//}

			// // // console.log(`OVER: ${obj.background}`);
		}
        
        return this;
    } // hover from Link central
    
	
	onScroll(data){
		const parseUnit = (val) => {
			if (val == null) return { num: 0, unit: "px" };
			const m = String(val).match(/^(-?[\d.]+)(.*)$/);
			return m ? { num: parseFloat(m[1]), unit: m[2] || "px" } : { num: 0, unit: "px" };
		};

		const applyTrn = (valObj) => {
			const tx = valObj && valObj.tx != null ? valObj.tx : "0px";
			const ty = valObj && valObj.ty != null ? valObj.ty : "0px";
			this.res.style.transform = `translate3d(${tx}, ${ty}, 0)`;
		};

		// Set the element valMin offset on page load
		if (data.value === "opacity") {
			this.res.style.opacity = data.valMin;
		} else if (data.value === "scale") {
			this.res.style.transform = `scale(${data.valMin})`;
		} else if (data.value === "trn") {
			applyTrn(data.valMin);
		}

		const compute = () => {
			if (data.value === "trn") {
				const result = {};
				const axes = ["tx", "ty"];
				for (let i = 0; i < axes.length; i++) {
					const k = axes[i];
					const hasMin = data.valMin && data.valMin[k] != null;
					const hasMax = data.valMax && data.valMax[k] != null;
					if (hasMin || hasMax) {
						const a = parseUnit(hasMin ? data.valMin[k] : (hasMax ? data.valMax[k] : "0px"));
						const b = parseUnit(hasMax ? data.valMax[k] : (hasMin ? data.valMin[k] : "0px"));
						const num = this.smartRange(window.scrollY, {
							min: data.from,
							max: data.to
						}, {
							min: a.num,
							max: b.num
						});
						result[k] = `${num}${a.unit}`;
					}
				}
				applyTrn(result);
				return;
			}

			let resa = this.smartRange(window.scrollY, {
				min: data.from,
				max: data.to
			}, {
				min: data.valMin,
				max: data.valMax
			});

			if (data.value === "opacity") {
				this.res.style.opacity = resa;
			} else if (data.value === "scale") {
				this.res.style.transform = `scale(${resa})`;
			}
		};

		window.addEventListener("scroll", compute);

		// Fire at the beginning if user sets "from" value to 0
		if (data.from === 0) {
			compute();
		}
	}




	setAny(obj){
		this[Object.keys(obj)[0]] = [Object.values(obj)[0]];
	}

	setID(id){
		this.id = id;
	}

	setPrevText(prevText){ // 12:12:43 20/03/25 OK :)
		this.prevText = prevText;
	}

	getCSS(){
		return this.css;
	}


	 getPX(value) {
		const breakpoints = {
			xs: "0px",      // Extra small
			sm: "576px",    // Small
			md: "768px",    // Medium
			lg: "992px",    // Large
			xl: "1200px",   // Extra large
			xxl: "1400px",   // Extra extra large
			mxxl: "1800px"   // Extra extra large
		};
	
		return breakpoints[value] || "Invalid breakpoint"; // Fallback for invalid input
	}

	// [{ breakpoint: "sm" , values: [...]}]
	/*respad(arr){
		const react = () => { // 00:49:12 22/03/2025
			this.pad(arr[0].values);

			for(let i = 0; i < arr.length; i++) {
				let point = arr[i].breakpoint;
				if (window.matchMedia(`(min-width: ${this.getPX(point)}`).matches){
					this.pad(arr[i].values);
				}
			}
		}


		window.addEventListener("resize", react);
		react();
	}*/



	/*
respad(arr) {
  this._applyResponsive(arr, (applied) => {
    console.log("Applying padding for", applied.breakpoint);
    this.pad(applied.values);
  });
}*/
/**
 * @private
 * Sets up the single resize listener and runs all registered tasks.
 */

/**
 * @private
 * Sets up the single resize listener and runs all registered tasks.
 * Ensures setup logic runs only ONCE.
 */
_setupResponsiveManager() {
    // 1. Initialize tasks list if it doesn't exist
    this._responsiveTasks = this._responsiveTasks || [];

    // 2. Define the reactor function
    const react = () => {
        this._responsiveTasks.forEach(taskFn => {
            taskFn();
        });
    };

    // 3. Setup Event Listener (ONLY ONCE)
    // We check if the handler is already assigned to avoid duplicate listeners
    if (!this._responsiveHandler) {
        this._responsiveHandler = react;
        window.addEventListener("resize", react);
    }

    // 4. Trigger Execution (ALWAYS)
    // We run this every time this function is called (by resprop or respad)
    // to ensure the newly added task is executed immediately.
    setTimeout(() => {
        react();
    }, 0);
}


resprop(arr, op) {

	// alert(op);
	this.options = op;

    // --- 1. CONFIGURATION & NORMALIZATION ---
    const breakpoints = {
        default: [0, 100000], xs: [0, 575], sm: [576, 767], md: [768, 991],
        lg: [992, 1199], xl: [1200, 1399], xxl: [1400, 100000]
    };
    const excludedKeys = ['resprop', 'breakpoint', 'value', 'values', 'range']; 
    
    // A. Normalize ranges: Treat "800px" as [0, 800] (Max-Width logic)
    arr.forEach(item => {
        if (breakpoints[item.breakpoint] !== undefined) {
            item.range = breakpoints[item.breakpoint];
        } else if (Array.isArray(item.breakpoint) && item.breakpoint.length === 2) {
            item.range = [
                parseInt(item.breakpoint[0], 10), 
                parseInt(item.breakpoint[1], 10)
            ];
        } else {
            // "800px" now becomes [0, 800]
            item.range = [0, parseInt(item.breakpoint, 10)];
        }
    });

    // B. SORTING: Sort by MAX value ascending. 
    // This ensures that if width is 500px, "800px" is checked before "1060px".
    arr.sort((a, b) => a.range[1] - b.range[1]);

    // C. Ensure the default/fallback is present
    let defaultItem = arr.find(item => item.breakpoint === "default");
    if (!defaultItem) {
        defaultItem = { breakpoint: "default", range: breakpoints.default };
        arr.unshift(defaultItem);
    }
    
    // --- 2. STATE CAPTURE ---

    this.prevStyles = {};
    for (const prop in this.res.style) {
       if (this.res.style.hasOwnProperty(prop) && isNaN(parseInt(prop))) {
          this.prevStyles[prop] = this.res.style[prop];
        }
    }

    const responsiveProps = new Set();
    arr.forEach(bp => {
        Object.keys(bp).forEach(key => {
            if (!excludedKeys.includes(key) && key !== 'range') {
                responsiveProps.add(key);
            }
        });
    });

    // Fill defaultItem with fallback values
    responsiveProps.forEach(key => {
        if (defaultItem[key] === undefined) {
             defaultItem[key] = this.options[key] || "initial";
        }
    });

    // --- 3. CORE LOGIC ---
    const respropTask = () => {
        const width = window.innerWidth;
        let applied = defaultItem; 

        // 1. Find the first matching range. 
        // Because we sorted ascending, the smallest matching "max-width" wins.
        for (let i = 0; i < arr.length; i++) {
            const bp = arr[i];
            const [min, max] = bp.range;
            if (bp.breakpoint === "default") continue;

            if (width >= min && width <= max) {
                applied = bp;
                break;
            }
        }
        
        // --- Apply Styles ---
        
        // B. Reset: Apply base values first
        responsiveProps.forEach(key => {
            // Special handling for keySet during reset
            if (key === 'keySet') {
                const ks = defaultItem[key];
                if (ks && ks.key) this.res.style[ks.key] = ks.value;
            } else {
                this.res.style[key] = defaultItem[key];

				
            }
        });

		
        
        // C. Overrides: Apply matching breakpoint values
        for (const key in applied) {
		
			if (key === "exact"){
//alert(key);
console.log("APPL");
console.log(applied);
console.log(this.set);
this.set(applied);
//this.set({key: })
			}


            if (!excludedKeys.includes(key) && key !== 'range') {
                const value = applied[key];

                // NEW: Handle your keySet object {key: "...", value: "..."}
                if (key === 'keySet' && value && value.key) {
                    this.res.style[value.key] = value.value;
                } 
                // Handle internal methods (e.g., this.width("300px"))
                else if (typeof this[key] === 'function') {
                    this[key](value); 
                } 
                // Handle direct CSS property assignment
                else {
                    this.res.style[key] = value;
                }


				
            }
        }
    };

    // --- 4. REGISTRATION ---
    this._responsiveTasks = this._responsiveTasks || [];
    this._responsiveTasks.push(respropTask);
    this._setupResponsiveManager(); 
}


respad(arr) {

    // --- 1. CONFIGURATION & NORMALIZATION ---
    const breakpoints = {
        default: [0, 100000], xs: [0, 575], sm: [576, 767], md: [768, 991],
        lg: [992, 1199], xl: [1200, 1399], xxl: [1400, 100000]
    };
    // Note: 'values' is handled specifically here, so it is not excluded globally.
    
    // A. Normalize breakpoints and assign range (handles named, [min, max], and "px" inputs)
    arr.forEach(item => {
        if (breakpoints[item.breakpoint] !== undefined) {
            item.range = breakpoints[item.breakpoint];
        } else if (Array.isArray(item.breakpoint) && item.breakpoint.length === 2) {
            item.range = [parseInt(item.breakpoint[0], 10), parseInt(item.breakpoint[1], 10)];
        } else {
            item.range = [parseInt(item.breakpoint, 10), 100000]; 
        }
    });

    // B. Sort by the minimum value of the range
    arr.sort((a, b) => a.range[0] - b.range[0]);

    // C. Find/Ensure the base style object
    let defaultItem = arr.find(item => item.breakpoint === "default");
    if (!defaultItem) {
        defaultItem = { breakpoint: "default", range: breakpoints.default };
        arr.unshift(defaultItem);
    }
    
    // --- 2. STATE CAPTURE & RESET PREPARATION ---

    // D. Ensure 'defaultItem' has a 'values' property, falling back to the base 'pad' option.
    if (defaultItem.values === undefined) {
         defaultItem.values = this.options.pad || null;
    }


    // --- 3. CORE LOGIC: The Responsive Task Function ---
    const respadTask = () => {
        const width = window.innerWidth;
        let applied = defaultItem; 

        // 1. RANGE LOGIC: Find the exact breakpoint whose range matches the current width.
        for (let i = 0; i < arr.length; i++) {
            const bp = arr[i];
            const [min, max] = bp.range;

            if (bp.breakpoint === "default") continue;

            if (width >= min && width <= max) {
                applied = bp;
                break;
            }
        }
        
        // --- Apply Pad Style ---
        
        // Determine the final padding value: use applied.values if it exists, otherwise defaultItem.values
        const finalPadValue = applied.values !== undefined ? applied.values : defaultItem.values;


        
        if (finalPadValue !== undefined && finalPadValue !== null) {
            // Note: We trust this.pad handles the style application and clearing
            this.pad(finalPadValue);
        }
    };


    // --- 4. REGISTRATION ---
    this._responsiveTasks = this._responsiveTasks || [];
    this._responsiveTasks.push(respadTask);
    
    // Ensure the unified handler is set up and starts listening
    this._setupResponsiveManager(); 
}


/*
respad(arr) { // COOL
    // --- 1. CONFIGURATION & NORMALIZATION ---
    
    // Breakpoints defined by explicit [min, max] ranges
    const breakpoints = {
        default: [0, 100000],
        xs: [0, 575],
        sm: [576, 767],
        md: [768, 991],
        lg: [992, 1199], 
        xl: [1200, 1399],
        xxl: [1400, 100000]
    };

    // Control keys: We exclude keys not related to the responsive style or range.
    const excludedKeys = ['resprop', 'breakpoint', 'range']; 
    
    // A. Normalize custom breakpoints: Assign the [min, max] array to the 'range' property
    arr.forEach(item => {
        // 1. Check for named breakpoints (e.g., 'sm', 'md')
        if (breakpoints[item.breakpoint] !== undefined) {
            item.range = breakpoints[item.breakpoint];

        // 2. Check if the input is already an array [min, max] (e.g., [600, 700])
        } else if (Array.isArray(item.breakpoint) && item.breakpoint.length === 2) {
            const [min, max] = item.breakpoint;
            
            item.range = [
                parseInt(min, 10), 
                parseInt(max, 10)
            ];

        // 3. Assume the input is a single pixel string (e.g., "700px")
        } else {
            // Treat as a min-width override up to a large maximum
            const min = parseInt(item.breakpoint, 10);
            item.range = [min, 100000]; 
        }
    });

    // B. Sort by the minimum value of the range (range[0])
    arr.sort((a, b) => a.range[0] - b.range[0]);

    // C. Find/Ensure the base style object
    let defaultItem = arr.find(item => item.breakpoint === "default");
    if (!defaultItem) {
        defaultItem = { breakpoint: "default", range: breakpoints.default };
        arr.unshift(defaultItem);
    }
    
    // --- 2. STATE CAPTURE & RESET PREPARATION (Specific to 'pad'/'values') ---

    // D. Capture the initial base 'values' (which should be the base padding config)
    // NOTE: This assumes the non-responsive 'pad' was set via this.options.pad or similar.
    // For simplicity with your usage, we will use the 'values' from the defaultItem itself.
    
    // E. Ensure 'defaultItem' has a 'values' property, or it will use the base config.
    if (defaultItem.values === undefined) {
         // This assumes the core padding is defined elsewhere if not in the responsive array.
         // If no 'default' values are set, use the base 'pad' option if available.
         defaultItem.values = this.options.pad || null;
    }


    // --- 3. CORE LOGIC: The 'react' function (Responsive Style Application) ---

    const react = () => {
        const width = window.innerWidth;
        let applied = defaultItem; 

        // 1. RANGE LOGIC: Find the exact breakpoint whose range matches the current width.
        for (let i = 0; i < arr.length; i++) {
            const bp = arr[i];
            const [min, max] = bp.range;

            if (bp.breakpoint === "default") {
                continue; // Skip default, it's the fallback
            }

            // Check if width is WITHIN the [min, max] range
            if (width >= min && width <= max) {
                applied = bp;
                break; // Found the exact range.
            }
        }
        
        // --- Apply Pad Style ---
        
        // Determine the final padding value to apply:
        // Use applied.values if it exists, otherwise fall back to defaultItem.values
        const finalPadValue = applied.values !== undefined ? applied.values : defaultItem.values;

        
        if (finalPadValue !== undefined && finalPadValue !== null) {
            console.log("Applying padding for", applied.breakpoint);
            
            // Call the base 'pad' method with the structure found on the 'values' key.
            this.pad(finalPadValue);
        }
    };


    // --- 4. EVENT LISTENERS SETUP ---

    // Prevent duplicate listeners
    if (this._responsiveHandler) window.removeEventListener("resize", this._responsiveHandler);
    this._responsiveHandler = react;

    window.addEventListener("resize", react);
    
    // Defer the initial execution to solve the refresh race condition.
    setTimeout(() => {
        react();
    }, 0);
}*/


	/*resmar(arr){
		const react = () => { // 00:49:12 22/03/2025
			this.mar(arr[0].values);

			for(let i = 0; i < arr.length; i++) {
				let point = arr[i].breakpoint;
				if (window.matchMedia(`(max-width: ${this.getPX(point)}`).matches){
					this.mar(arr[i].values);
				}
			}
		}

		window.addEventListener("resize", react);
		react();
	}*/

_applyResponsive(arr, applyFn) {
  // Breakpoints defined by explicit [min, max] ranges
  const breakpoints = {
    default: [0, 100000], 
    xs: [0, 575],
    sm: [576, 767],
    md: [768, 991],
    lg: [992, 1199], 
    xl: [1200, 1399],
    xxl: [1400, 100000] 
  };

  // ✅ Normalize breakpoints: Assign the [min, max] array to the 'range' property
  arr.forEach(item => {
    if (breakpoints[item.breakpoint] !== undefined) {
      item.range = breakpoints[item.breakpoint];
    } else {
      const min = parseInt(item.breakpoint, 10);
      item.range = [min, 100000]; // Custom pixel value becomes a Min-Width range
    }
  });

  // ✅ Sort by the minimum value of the range (range[0])
  arr.sort((a, b) => a.range[0] - b.range[0]);

  // Use the default item or a placeholder as the base
  const defaultItem = arr.find(item => item.breakpoint === "default") || { breakpoint: "default", range: breakpoints.default };

  const react = () => {
    const width = window.innerWidth;
    let applied = defaultItem; // Start with the base style object

    // ✅ RANGE LOGIC: Find the FIRST breakpoint whose range matches the current width.
    for (let i = 0; i < arr.length; i++) {
      const bp = arr[i];
      const [min, max] = bp.range;

      if (bp.breakpoint === "default") {
          continue; // Skip default, it's the fallback
      }

      // Check if width is WITHIN the [min, max] range
      if (width >= min && width <= max) {
        applied = bp;
        break; // Found the exact range, no need to search further.
      }
    }

    applyFn(applied);
  };


  // Prevent duplicate listeners
  if (this._responsiveHandler) window.removeEventListener("resize", this._responsiveHandler);
  this._responsiveHandler = react;

  window.addEventListener("resize", react);
  
  // ⭐ FIX: Defer the initial call slightly to avoid race conditions on refresh.
  setTimeout(() => {
    react(); 
  }, 0);
}

/*
resprop(arr) { // COOL
    // --- 1. CONFIGURATION & NORMALIZATION ---
    
    // Breakpoints defined by explicit [min, max] ranges
    const breakpoints = {
        default: [0, 100000], // Use a huge max for default/base
        xs: [0, 575],
        sm: [576, 767],
        md: [768, 991],
        lg: [992, 1199], // Corrected range assumption based on XL starting at 1200
        xl: [1200, 1399],
        xxl: [1400, 100000] // Use a huge max for the largest range
    };

    // Ensure all control keys are excluded
    const excludedKeys = ['resprop', 'breakpoint', 'value', 'values']; 
    
    // A. Normalize custom breakpoints: Attach the [min, max] array to the item
    /*arr.forEach(item => {
        if (breakpoints[item.breakpoint] !== undefined) {
            item.range = breakpoints[item.breakpoint];
        } else {
            // If a custom pixel value is used (e.g., "700px"), treat it as a min-width override.
            const min = parseInt(item.breakpoint, 10);
            item.range = [min, 100000]; 
        }
    });

	arr.forEach(item => {
    // 1. Check for named breakpoints (e.g., 'sm', 'md')
    if (breakpoints[item.breakpoint] !== undefined) {
        item.range = breakpoints[item.breakpoint];

    // 2. Check if the input is already an array [min, max] (e.g., [600, 700])
    } else if (Array.isArray(item.breakpoint) && item.breakpoint.length === 2) {
        const [min, max] = item.breakpoint;
        
        // Ensure values are treated as numbers and min <= max
        item.range = [
            parseInt(min, 10), 
            parseInt(max, 10)
        ];

    // 3. Assume the input is a single pixel string (e.g., "700px")
    } else {
        // Treat as a min-width override up to a large maximum
        const min = parseInt(item.breakpoint, 10);
        item.range = [min, 100000]; 
    }
});

    // B. Sort by the minimum value of the range (range[0])
    arr.sort((a, b) => a.range[0] - b.range[0]);

    // C. Find/Ensure the base style object
    let defaultItem = arr.find(item => item.breakpoint === "default");
    if (!defaultItem) {
        defaultItem = { breakpoint: "default", range: breakpoints.default };
        arr.unshift(defaultItem);
    }
    
    // --- 2. STATE CAPTURE & RESET PREPARATION ---

    // D. Capture initial non-responsive styles (for global reset)
    this.prevStyles = {};
    for (const prop in this.res.style) {
       if (this.res.style.hasOwnProperty(prop) && isNaN(parseInt(prop))) {
          this.prevStyles[prop] = this.res.style[prop];
        }
    }

    // E. Identify all properties that are responsive (defined in *any* breakpoint)
    const responsiveProps = new Set();
    arr.forEach(bp => {
        Object.keys(bp).forEach(key => {
            if (!excludedKeys.includes(key) && key !== 'range') {
                responsiveProps.add(key);
            }
        });
    });

    // F. Ensure 'defaultItem' holds the base/reset value for every responsive property.
    responsiveProps.forEach(key => {
        if (defaultItem[key] === undefined) {
             // Use the initial component option (e.g., color: "white") as the true reset value.
             defaultItem[key] = this.options[key] || "initial";
        }
    });


    // --- 3. CORE LOGIC: The 'react' function (Responsive Style Application) ---

    const react = () => {
        const width = window.innerWidth;
        let applied = defaultItem; 

        // 1. RANGE LOGIC: Find the FIRST breakpoint whose range matches the current width.
        // We skip defaultItem since it's the fallback.
        for (let i = 0; i < arr.length; i++) {
            const bp = arr[i];
            const [min, max] = bp.range;

            if (bp.breakpoint === "default") {
                continue; // Skip default, it's the fallback
            }

            // Check if width is WITHIN the [min, max] range
            if (width >= min && width <= max) {
                applied = bp;
                break; // Found the exact range, no need to search further.
            }
        }
        
        // --- Apply Styles ---
        
        // A. Full Reset: Restore all non-responsive styles captured initially.
        for (const key in this.prevStyles) {
            this.res.style[key] = this.prevStyles[key];
        }

        // B. Clear Responsive Props: Apply the 'default' item's base values.
        responsiveProps.forEach(key => {
            this.res.style[key] = defaultItem[key];
        });
        
        // C. Apply Overrides: Apply the properties of the currently matching breakpoint
        for (const key in applied) {
            if (!excludedKeys.includes(key) && key !== 'range') {
                const value = applied[key];

                if (typeof this[key] === 'function') {
                    // Custom property (e.g., pad, size): call the internal method
                    this[key](value); 
                } else {
                    // Standard CSS property: set the style directly.
                    this.res.style[key] = value;
                }
            }
        }
    };


    // --- 4. EVENT LISTENERS SETUP ---

    // Prevent duplicate listeners
    if (this._responsiveHandler) window.removeEventListener("resize", this._responsiveHandler);
    this._responsiveHandler = react;

    window.addEventListener("resize", react);
    
    // Defer the initial execution to solve the refresh race condition.
    setTimeout(() => {
        react();
    }, 0);
}*/

/*
resprop(arr) {
    // --- 1. CONFIGURATION & NORMALIZATION ---
    const breakpoints = {
        default: 0,
        xs: [0, 577],
        sm: [576, 767],
        md: [768, 991],
        lg: [992, 993],
        xl: [1200, 1399],
        xxl: [1400, 10000]
    };
    // Ensure all control keys are excluded
    const excludedKeys = ['resprop', 'breakpoint', 'value', 'values']; 

    // A. Normalize custom breakpoints and assign numeric values to the 'value' property
    arr.forEach(item => {
        if (breakpoints[item.breakpoint] !== undefined) {
            item.value = breakpoints[item.breakpoint];
        } else {
            item.value = parseInt(item.breakpoint, 10); // e.g. "700px" → 700
        }
    });

    // B. Sort by numeric value ascending
    arr.sort((a, b) => a.value - b.value);

    // C. Find/Ensure the base style object
    let defaultItem = arr.find(item => item.breakpoint === "default");
    if (!defaultItem) {
        defaultItem = { breakpoint: "default", value: 0 };
        arr.unshift(defaultItem);
    }
    
    // --- 2. STATE CAPTURE & RESET PREPARATION ---

    // D. Capture initial non-responsive styles (for global reset)
    this.prevStyles = {};
    for (const prop in this.res.style) {
       if (this.res.style.hasOwnProperty(prop) && isNaN(parseInt(prop))) {
          this.prevStyles[prop] = this.res.style[prop];
        }
    }

    // E. Identify all properties that are responsive (defined in *any* breakpoint)
    const responsiveProps = new Set();
    arr.forEach(bp => {
        Object.keys(bp).forEach(key => {
            if (!excludedKeys.includes(key)) {
                responsiveProps.add(key);
            }
        });
    });

    // F. Ensure 'defaultItem' holds the base/reset value for every responsive property.
    responsiveProps.forEach(key => {
        if (defaultItem[key] === undefined) {
             // Use the initial component option (e.g., color: "white") as the true reset value.
             defaultItem[key] = this.options[key] || "initial";
        }
    });


    // --- 3. CORE LOGIC: The 'react' function (Responsive Style Application) ---

    const react = () => {
        const width = window.innerWidth;
        let applied = defaultItem; 

        // 1. STANDARD MIN-WIDTH LOGIC: Find the LARGEST breakpoint whose MIN-WIDTH is matched.
        for (let i = 0; i < arr.length; i++) {
            const bp = arr[i];

            if (bp.breakpoint !== "default" && width >= bp.value) {
                // Since the array is sorted, this continuously updates 'applied' to the widest match.
                applied = bp;
            } else if (width < bp.value) {
                // Optimization: stop searching once the breakpoint value is greater than the current width.
                break; 
            }
        }
        
        // --- Apply Styles ---
        
        // A. Full Reset: Restore all non-responsive styles captured initially.
        for (const key in this.prevStyles) {
            this.res.style[key] = this.prevStyles[key];
        }

        // B. Clear Responsive Props: Apply the 'default' item's base values (e.g., "white" color)
        // This is done for all responsive properties to ensure a clean slate before applying overrides.
        responsiveProps.forEach(key => {
            this.res.style[key] = defaultItem[key];
        });
        
        // C. Apply Overrides: Apply the properties of the currently matching breakpoint
        for (const key in applied) {
            if (!excludedKeys.includes(key)) {
                const value = applied[key];

                if (typeof this[key] === 'function') {
                    // Custom property (e.g., pad, size): call the internal method
                    this[key](value); 
                } else {
                    // Standard CSS property: set the style directly.
                    this.res.style[key] = value;
                }
            }
        }
    };


    // --- 4. EVENT LISTENERS SETUP (The Fix for Resize/Refresh) ---

    // Prevent duplicate listeners
    if (this._responsiveHandler) window.removeEventListener("resize", this._responsiveHandler);
    this._responsiveHandler = react;

    window.addEventListener("resize", react);
    
    // Run immediately on load/refresh (This ensures the correct styles are applied on initial load)
   // react();
   setTimeout(() => {
        react();
    }, 0);
}*/

/*
resmar(arr) {
  this._applyResponsive(arr, (applied) => {
    console.log("Applying margin for", applied.breakpoint);
    this.mar(applied.values);
  });
}*/


resmar(arr) {

    // --- 1. CONFIGURATION & NORMALIZATION ---
    const breakpoints = {
        default: [0, 100000], xs: [0, 575], sm: [576, 767], md: [768, 991],
        lg: [992, 1199], xl: [1200, 1399], xxl: [1400, 100000]
    };
    // Note: 'values' is handled specifically here, so it is not excluded globally.
    
    // A. Normalize breakpoints and assign range (handles named, [min, max], and "px" inputs)
    arr.forEach(item => {
        if (breakpoints[item.breakpoint] !== undefined) {
            item.range = breakpoints[item.breakpoint];
        } else if (Array.isArray(item.breakpoint) && item.breakpoint.length === 2) {
            item.range = [parseInt(item.breakpoint[0], 10), parseInt(item.breakpoint[1], 10)];
        } else {
            item.range = [parseInt(item.breakpoint, 10), 100000]; 
        }
    });

    // B. Sort by the minimum value of the range
    arr.sort((a, b) => a.range[0] - b.range[0]);

    // C. Find/Ensure the base style object
    let defaultItem = arr.find(item => item.breakpoint === "default");
    if (!defaultItem) {
        defaultItem = { breakpoint: "default", range: breakpoints.default };
        arr.unshift(defaultItem);
    }
    
    // --- 2. STATE CAPTURE & RESET PREPARATION ---

    // D. Ensure 'defaultItem' has a 'values' property, falling back to the base 'pad' option.
    if (defaultItem.values === undefined) {
         defaultItem.values = this.options.pad || null;
    }


    // --- 3. CORE LOGIC: The Responsive Task Function ---
    const resmarTask = () => {
        const width = window.innerWidth;
        let applied = defaultItem; 

        // 1. RANGE LOGIC: Find the exact breakpoint whose range matches the current width.
        for (let i = 0; i < arr.length; i++) {
            const bp = arr[i];
            const [min, max] = bp.range;

            if (bp.breakpoint === "default") continue;

            if (width >= min && width <= max) {
                applied = bp;
                break;
            }
        }
        
        // --- Apply Pad Style ---
        
        // Determine the final padding value: use applied.values if it exists, otherwise defaultItem.values
        const finalPadValue = applied.values !== undefined ? applied.values : defaultItem.values;


        
        if (finalPadValue !== undefined && finalPadValue !== null) {
            // Note: We trust this.pad handles the style application and clearing
            this.mar(finalPadValue);
        }
    };


    // --- 4. REGISTRATION ---
    this._responsiveTasks = this._responsiveTasks || [];
    this._responsiveTasks.push(resmarTask);
    
    // Ensure the unified handler is set up and starts listening
    this._setupResponsiveManager(); 
}



	/*resprop(arr) {

		this.prevBackground = this.res.style.background;
			this.prevWidth = this.res.style.width;
			this.prevHeight = this.res.style.height;
			this.prevBorder = this.res.style.border;


		const react = () => { // 00:49:12 22/03/2025

			this.res.style.background = this.prevBackground;
			this.res.style.width = this.prevWidth;
			this.res.style.height = this.prevHeight;
			this.res.style.border = this.prevBorder;

			for (let i = 0; i < arr.length; i++) {
				let point = arr[i].breakpoint;
				if (window.matchMedia(`(max-width: ${this.getPX(point)}`).matches) {
					const filteredObj = {};
					for (const key in arr[i]) {
						if (key !== "breakpoint") {
							filteredObj[key] = arr[i][key];
						}
					}

					this.set(filteredObj);
				}
			}
		}


		window.addEventListener("resize", react);
		react();
	}*/

	isNumber(value) {
		return typeof value === 'number' && !isNaN(value);
	}
 
	pad(arr){

		for(let i = 0; i < arr.length; i++) {
	
			let keys = Object.keys(arr[i]);
			for(let j = 0; j < keys.length; j++) {
				let key = keys[j];
				let value = arr[i][key];
				for(let k = 0; k < key.length; k++) {
					switch(key[k]) {
						case 'a':
							
							//alert("OIHOI")
							this.res.style.padding = this.isNumber(value) ? `${value}px` : value;
							break;
						case 't':
							this.res.style.paddingTop =  this.isNumber(value) ? `${value}px` : value;
							break;
						case 'l':
							this.res.style.paddingLeft =  this.isNumber(value) ? `${value}px` : value;
							break;
						case 'r':
							this.res.style.paddingRight =  this.isNumber(value) ? `${value}px` : value;
							break;
						case 'b':
							this.res.style.paddingBottom =  this.isNumber(value) ? `${value}px` : value;
							break;
						default:
							// console.log(`Invalid key: ${key[k]}`);
					}
				}
			}
		}
		return this;
	}


	as(asa){
		this.res.style.alignSelf = asa;
		return this;
	}



	mar(arr){

		// Shorthand: mar: "center" → margin: 0 auto
		if (arr === "center"){
			this.res.style.marginLeft = "auto";
			this.res.style.marginRight = "auto";
			return this;
		}

		for(let i = 0; i < arr.length; i++) {
			let keys = Object.keys(arr[i]);
			for(let j = 0; j < keys.length; j++) {
				let key = keys[j];
				let value = arr[i][key];
				for(let k = 0; k < key.length; k++) {
					switch(key[k]) {
						case 'a':
							// mar: [{ a: "auto" }] → margin: 0 auto (centers block-level elements)
							if (value === "auto"){
								this.res.style.marginLeft = "auto";
								this.res.style.marginRight = "auto";
							} else {
								this.res.style.margin = this.isNumber(value) ? `${value}px` : value;
							}
							break;
						case 't':
							this.res.style.marginTop = this.isNumber(value) ? `${value}px` : value;
							break;
						case 'l':
							this.res.style.marginLeft = this.isNumber(value) ? `${value}px` : value;
							break;
						case 'r':
							this.res.style.marginRight = this.isNumber(value) ? `${value}px` : value;
							break;
						case 'b':
							this.res.style.marginBottom = this.isNumber(value) ? `${value}px` : value;
							break;
						default:
							// console.log(`Invalid key: ${key[k]}`);
					}
				}

				// Per-entry shorthand: { center: true } → marginLeft/Right = auto
				if (key === "center" && value === true){
					this.res.style.marginLeft = "auto";
					this.res.style.marginRight = "auto";
				}

				// Value-based detection: if any value === "auto" on l/r/lr keys, force centering
				if (value === "auto" && (key.includes("l") || key.includes("r"))){
					if (key.includes("l")) this.res.style.marginLeft = "auto";
					if (key.includes("r")) this.res.style.marginRight = "auto";
				}
			}
		}
		return this;
	}


 smartRange(val, from, to) {

    if (val < from.min) {
        val = from.min;
    }

    if (val > from.max) {
        val = from.max;
    }

    let percent = (val - from.min) / (from.max - from.min);

    if (from.min > from.max) {
        percent = (val - from.max) / (from.min - from.max);
    }

    let toRange = (to.min - to.max) * percent - to.min;
    toRange = Math.abs(toRange);

    if (to.min < to.max) {
        let sm = to.max + Math.abs(to.min);
        let timesPerc = sm * percent;
        toRange = to.min + timesPerc;
    }


    return toRange;
}


	gpos(obj){
		//alert(obj.col);
		this.res.style.gridColumn = obj.col;
		this.res.style.gridRow = obj.row;
		//this.res.style.border = "1px solid green";
		return this;
	  }

	fluidCopy(name){


		if (name instanceof Object){
			this.prevStylex = this.res.style;
			this.res = document.createElement("h1");
			this.res.style.cssText = this.prevStylex.cssText;
			let node = document.createTextNode(this.text);
			this.res.appendChild(node);
             this.res.style.fontSize = name.exact;

			 // alert(name.exact);

			return this;
		}
        
        const display1 = "calc(1.625rem + 5.075vw)";
        
        if (name === "S1"){
			this.prevStylex = this.res.style;
			this.res = document.createElement("h1");
			this.res.style.cssText = this.prevStylex.cssText;
			let node = document.createTextNode(this.text);
			this.res.appendChild(node);
             this.res.style.fontSize = display1;
        }
         
        const display2 = "calc(1.500rem + 4.3vw)";
        
        if (name === "S2"){
			this.prevStylex = this.res.style;
			this.res = document.createElement("h2");
			this.res.style.cssText = this.prevStylex.cssText;
			let node = document.createTextNode(this.text);
			this.res.appendChild(node);
             this.res.style.fontSize = display2;
        }
        
        
        const display3 = "calc(1.375rem + 3.525vw)";
        
        if (name === "S3"){
			this.prevStylex = this.res.style;
			this.res = document.createElement("h3");
			this.res.style.cssText = this.prevStylex.cssText;
			let node = document.createTextNode(this.text);
			this.res.appendChild(node);
             this.res.style.fontSize = display3;
        }

		const display4 = "calc(1.250rem + 2.75vw)";
        
        if (name === "S4"){
			this.prevStylex = this.res.style;
			this.res = document.createElement("h4");
			this.res.style.cssText = this.prevStylex.cssText;
			let node = document.createTextNode(this.text);
			this.res.appendChild(node);
             this.res.style.fontSize = display4;
        }

		const display5 = "calc(1.125rem + 1.975vw)";
        
        if (name === "S5"){
			this.prevStylex = this.res.style;
			this.res = document.createElement("h5");
			this.res.style.cssText = this.prevStylex.cssText;
			let node = document.createTextNode(this.text);
			this.res.appendChild(node);
            this.res.style.fontSize = display5;
        }



		const display6 = "calc(1rem + 0.5vw)"; // calc(1rem + 1.2vw)
        
        if (name === "S6"){
             this.res.style.fontSize = display6;
        }
        
              return this;
    }


	
    
    setIndex(idx){
		this.index = idx;
	}

	borderObj(options){
		let type = options.type ?? "solid";
		this.res.style.border = `${options.width} ${type} ${options.color}`
		// Only touch borderRadius when the caller actually provided one.
		// Otherwise we'd clobber the radius set via the styleMap (e.g.
		// `radius: "50%"` on a circle) with `undefined`, which clears it.
		if (options.radius !== undefined) {
			this.res.style.borderRadius = options.radius;
		}
		return this;
	}
    
/*
 protoReact(queries, id) {
	// Sort the queries based on the starting range value in ascending order
	queries.sort((a, b) => parseInt(a.range[0]) - parseInt(b.range[0]));
  
	// Function to check and log queries based on screen size
	const checkQueries =() => {
	  const screenSize = window.innerWidth;
	  let ops = "";

	  this.storedQueries = queries.map(el => el.target).filter(el => el != undefined);
  
	  for (const query of queries) {
		this.counterIndex++;

		const [startRange, endRange] = query.range;
		const startSize = parseInt(startRange);
		const endSize = parseInt(endRange);


		let all = true;

		if (query.target){
			all = false;

			for (var i = 0; i < query.target.length; i++){
				if (query.target[i] === id){ // #id is required
					all = true;
				}
			}
		} 
  
		if (screenSize >= startSize && screenSize <= endSize && all) { // NEED TO COMMENT ALL
		// USE THIS, but apply all properties all the time !! 255447

		  if (query.log === "gradient"){
			ops += "gradient";
		  }

		  if (query.log === "blast"){
			ops += "blast";
		  }

		  if (query.log === "animation"){
			ops += "animation";
		  }

		  if (query.log === "shadow"){
			ops += "shadow";
		  }

		  if (query.log === "span"){
			ops += "span";
		  }

		  if (query.log === "filter"){
			ops += "filter";
		  }

		  if (query.log === "background"){
			ops += "background";
		  }
		} 
	  }
	
	
	  this.res.style.margin = "";
	  // Everything works 12:48:45 06/10/23

	  let defaultColor = this.res.style.color; // 11:05:40 Nice

		let mapped = queries.map(el => el.log).filter(el => el != undefined);
		
		if (mapped.includes("gradient")) {
			this.res.style.WebkitBackgroundClip = "";
			this.res.style.background = "";
		}


	  // Reset stroke
	  this.res.style['-webkit-text-stroke'] = "";
	  this.res.style.filter = ``;

	  // Reset shadow
	  this.res.style.textShadow = "";

      // Temp reset border
      this.res.style.border = "";
	  
	  while(this.res.firstChild) {  // not the problem...
		this.res.removeChild(this.res.firstChild); // Remove all children
	}

	this.res.textContent = this.text;

		if (ops === "") {
			this.res.style['-webkit-text-fill-color'] = '';
			this.res.style.color = defaultColor; //"green";
		}


		if (ops === "blast") { // Chekc id here ???
		   for (var i = 0; i < queries.length; i++){
			const off  = queries[i].op.offsets;

			if (off && this.index !== undefined){
				this.res.style.margin = off[Number(this.index)] + "px";
			}
		}

			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style['-webkit-text-stroke'] = this.globalBlast; //this.globalBlast; //`3px orange`;
	
			for (var i = 0; i < queries.length; i++){
				const off  = queries[i].op.offsets;
				if (off && this.index !== undefined){
					this.res.style.margin = off[Number(this.index)] + "px";
				}
			}
		}
	
		

		if (ops === "gradient") { // the problem is not here
			this.res.style['-webkit-text-fill-color'] = 'transparent';
		    this.res.style.background = this.globalGradient;// "linear-gradient(to left, #3498db, #1abc9c)";
			this.res.style['-webkit-background-clip'] = 'text';
		    this.res.style.border = "1px solid orange"; // Something on Wrapper prevents border works on text
		}
	

		if (ops === "background"){
			this.res.style.background = "orange";
		}

	
		if (ops === "gradientblast") { 
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style.background = this.globalGradient;//"linear-gradient(to left, #3498db, #1abc9c)";
			this.res.style['-webkit-background-clip'] = 'text';
			this.res.style['-webkit-text-stroke'] = this.globalBlast; // `3px orange`;
		}

		if (ops === "gradientanimation") { // 12:33:14 Nice
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style.background = this.globalGradient; //"linear-gradient(to left, #3498db, #1abc9c)";
			this.res.style['-webkit-background-clip'] = 'text';
		}

		if (ops === "gradientanimationshadow"){
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style.background = this.globalGradient; //"linear-gradient(to left, #3498db, #1abc9c)";
			this.res.style['-webkit-background-clip'] = 'text';
			this.res.style.textShadow = this.globalShadow; //"#1abc9cff -6px 6px, #1abc9c9f -12px 12px, #1abc9c40 -18px 18px";
		}

		if (ops === "animationshadow"){
			this.res.style['-webkit-text-fill-color'] = '';
			this.res.style.textShadow = this.globalShadow; //"#1abc9cff -6px 6px , #1abc9c40 -12px 12px";
		}

		if (ops === "shadow"){
			// Clear all children and add text content
			this.res.style['-webkit-text-fill-color'] = '';
			this.res.style.textShadow = this.globalShadow; //"#1abc9cff -6px 6px , #1abc9c40 -12px 12px";
		}


		if (ops === "span"){
			if (this.options.span){
				let noiseObject;
	
				if (Array.isArray(this.options.span)){
					noiseObject = this.options.span.filter(a => a.op.name === "span")[0];
				} else {
					noiseObject = this.options.span;
				}

				this.res.textContent = ""; // creating new element not helping
	
				for (var i = 0; i < noiseObject.op.parts.length; i++){
					let opts = noiseObject.op.parts[i].style;
					let span = new Text(noiseObject.op.parts[i].text).setup({type: "span"}).set(opts).render();
					this.res.appendChild(span);
				}
			}
		}
	  

		if (ops === "filter"){
			let filterName = this.options.filtera.op.filter;
			this.res.style.filter = filterName;
			this.res.style.border = "8px solid orange";
		}
	}
  
	// Add an event listener to check queries on window resize
	window.addEventListener('resize', checkQueries);
  
	// Initial check
	checkQueries();
  }
*/



setPref(id){
	this.preffersId = id;
}


setClass(id){
	this.class = id;
}



/*
 betaReact(queries, id) {

	this.ap = false;
	this.cta = 0;
	this.once = false;
	queries.sort((a, b) => parseInt(a.range[0]) - parseInt(b.range[0]));
  
	// Function to check and log queries based on screen size
	const checkQueries =() => {
	  const screenSize = window.innerWidth;
	  let ops = "";

	  this.resCopy = this.res;

	  this.storedQueries = queries.map(el => el.target).filter(el => el != undefined);
	  // // // console.log(this.storedQueries);
  
	  for (const query of queries) {
		this.counterIndex++;

		const [startRange, endRange] = query.range;
		const startSize = parseInt(startRange);
		const endSize = parseInt(endRange);
		let all = true;

		if (query.target){
		//alert("KKK")
			all = false;
		//alert(this.res.id);

			for (var i = 0; i < query.target.length; i++){
				// // // console.log("QT " + query.target[i]);
				// // // console.log("QS " + id);

				if (query.target[i] === id){ // #id is required
				
					all = true;
				}
			}
		} 
  
		if (screenSize >= startSize && screenSize <= endSize && all) { // NEED TO COMMENT ALL
		  if (query.log === "blast"){
			ops += "blast";
		  }

		  if (query.log === "shadow"){
			ops += "shadow";
		  }

		  if (query.log === "background"){
			ops += "background";
		  }

		  if (query.log === "gradient"){
			ops += "gradient";
		  }

		  if (query.log === "spana"){
			ops += "spana";
		  }

		  if (query.log === "layout"){
			ops += "layout";
		  }

		  if (query.log === "margin"){
			ops += "margin";
		  }

		  if (query.op && query.op.margin){
			this.useMargin = query.op.margin;
		  }
		} 

	  }



	  this.res.style.background = "";
	  this.res.style.backgroundColor = "";
	  this.res.style.textShadow = "";
	  this.res.style.border = "";
	  this.res.style.margin = ""

	  this.res.style['-webkit-text-fill-color'] = '';
		this.res.style['-webkit-text-stroke'] = "";
		this.res.style['-webkit-text-stroke-width'] = "";

	  if (ops === "background"){
		// alert("PPPA")
		this.res.style.backgroundColor = "green";
	  }

	  if (ops === "margin"){

		for (var i = 0; i < queries.length; i++){

			if (!queries[i].op){
				continue;
			}
			const off  = queries[i].op.offsets;
			if (off && this.index !== undefined){
				this.res.style.margin = off[Number(this.index)] + "px";
			}
		}

		
	  }

	  if (ops === "blastbackgroundmargin"){
	
	for (var i = 0; i < queries.length; i++){
		if (!queries[i].op){
			continue;
		}

		const off  = queries[i].op.offsets;
		// console.log(off);
		
		if (off && this.index !== undefined){
			 // console.warn("READ INDEX");
			this.res.style.margin = off[Number(this.index)] + "px";
		}
	}
		

		this.res.style.backgroundColor = "green";
		//this.useMargin ? this.res.style.margin = "1rem" : null;
		// alert("PPPA")
		if (this.getType() === "FlexRowLayoutElement"){
			this.res.style.border = "1px solid orange";
		} else {
			this.res.textContent = this.text; //"a"
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			//this.res.style['-webkit-background-clip'] = 'text';
			this.res.style['-webkit-text-stroke-color'] = "orange";
			this.res.style['-webkit-text-stroke-width'] = "1px";
		}
		
		this.res.style['-webkit-text-fill-color'] = 'transparent';
		this.res.style['-webkit-text-stroke-color'] = "orange";
		this.res.style['-webkit-text-stroke-width'] = "1px";
	  }

	  if (ops === "blastbackground"){

		for (var i = 0; i < queries.length; i++){
			if (!queries[i].op){
				continue;
			}

			const off  = queries[i].op.offsets;

			if (off && this.index !== undefined){
				this.res.style.margin = off[Number(this.index)] + "px";
			}
		}
	
		this.res.style.backgroundColor = "green";
		// no unused expression
		this.useMargin ? this.res.style.margin = "1rem" : this.res.setAttribute("id", "iofhwoiefhoih");
		//this.useMargin ? this.res.style.margin = "1rem" : null;
		if (this.getType() === "FlexRowLayoutElement"){
			this.res.style.border = "1px solid orange";
		} else {
			this.res.textContent = this.text; //"a"
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style['-webkit-text-stroke-color'] = "orange";
			this.res.style['-webkit-text-stroke-width'] = "1px";
		}
		
		this.res.style['-webkit-text-fill-color'] = 'transparent';
		this.res.style['-webkit-text-stroke-color'] = "orange";
		this.res.style['-webkit-text-stroke-width'] = "1px";
	  }

	  if (ops === "layout"){
		this.res.style.alignSelf = "start";
		this.res.style.border = "1px solid purple";
	  }


		

	  if (ops === "blast") { // the problem is not here
		
		for (var i = 0; i < queries.length; i++){
			if (!queries[i].op){
				continue;
			}
			
			const off  = queries[i].op.offsets;
			if (off && this.index !== undefined){
				this.res.style.margin = off[Number(this.index)] + "px";
			}
		}
		
		if (this.getType() === "FlexRowLayoutElement"){
			this.res.style.border = "1px solid orange";
		} else {
			this.res.textContent = this.text; //"a"
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style['-webkit-background-clip'] = 'text';
			this.res.style['-webkit-text-stroke-color'] = "orange";
			this.res.style['-webkit-text-stroke-width'] = "1px";
		}
		
		this.res.style['-webkit-text-fill-color'] = 'transparent';
		this.res.style['-webkit-text-stroke'] = "orange";
		this.res.style['-webkit-text-stroke-width'] = "1px";
	}


	if (ops === "blastgradientbackground"){
		this.res.style.border = "1px solid yellow";
		this.res.style['-webkit-text-stroke-color'] = "orange";
		this.res.style['-webkit-text-stroke-width'] = "1px";
	}


	

	if (ops === "gradient") {
		
		//alert("P")
		
		this.res.style.background = "linear-gradient(to left, #3498db, #1abc9c)";
		
		if (this.getType() === "FlexRowLayoutElement"){
		} else {

			this.res.children[0] && this.res.removeChild(this.res.children[0]);
			//// console.warn(this.res.children[0]);
			this.res.style['-webkit-text-fill-color'] = 'transparent';
			this.res.style['-webkit-background-clip'] = 'text';
			this.res.textContent = this.text; //"a"
			//this.res.children[0] && this.res.removeChild(this.res.children[0]);
		}
	}





	  if (operations.includes("shadow")){
			if (this.getType() === "FlexRowLayoutElement"){
			} else {
		
				let str = "";
				let off = 0;
				for (var i = 0; i < this.options.shadow.op.steps; i++){
					off += 3;

					let color = this.options.shadow.op.colors[i];
					str += `drop-shadow(${off}px ${off}px ${off}px ${color}) `; 
				}


				this.res.style.filter = str; 
				
		}
	  }

	}
  
	// Add an event listener to check queries on window resize
	window.addEventListener('resize', checkQueries);
  
	// Initial check
	checkQueries();
  }*/


  //--------- START OF INDEPENDENT


// React without condition 
// loop through queries 
// to make all CSS immediatelly...

 /* cssGen(queries, id, classa, preffersClass){

	this.css = [""];
	return [""];

	this.css = [];
	queries.sort((a, b) => parseInt(a.range[0]) - parseInt(b.range[0]));
  
	// Function to check and log queries based on screen size
	const checkQueries =() => {
	  const screenSize = window.innerWidth;
	  let ops = "";
	  let operations = [];

	  this.resCopy = this.res;

	  this.storedQueries = queries.map(el => el.target).filter(el => el != undefined);
	 
	  // console.log("ULTRA");
	  // console.log(queries);

	  
  
	  for (const query of queries) {
		this.counterIndex++;

		const [startRange, endRange] = query.range;
		const startSize = parseInt(startRange);
		const endSize = parseInt(endRange);
		let all = true;

		

		if (query.target){
			//alert("KKK")
				all = false;
			//alert(this.res.id);
	
				for (var i = 0; i < query.target.length; i++){
					// // // console.log("QT " + query.target[i]);
					// // // console.log("QS " + id);
	
					if (query.target[i] === id){ // #id is required
					
						all = true;
					}
				}
			} 





		
if (all){ // make it work only with ID ???


		operations.push(query.log);

		let range = `\n @media (min-width: ${startSize}px) and (max-width: ${endSize}px)`;
		this.range = range; // this.range is always the last one!!!
		this.css.push({log: query.log, range: range, rules:[]});
}
	}

	

	if (operations.includes("blast")){
		let ft = this.css.map(q => q.log).lastIndexOf("blast");
		//// console.log("BLAST IDO IS " + ft + "TR" + this.range);

		// should be 0-900
		// is 880-930
//alert(this.preffersId);
//alert(this.class);

		this.css[ft].rules.push(` 
		${this.preffersId ? id : "." + this.class}{
			-webkit-text-stroke-width: 1px;
			-webkit-text-stroke-color: orange;
			-webkit-text-fill-color: transparent;
		}
		`);
	}

	if (operations.includes("gradient")){
		//let ft = this.css.map(q => q.range).lastIndexOf(this.range);
		//// console.log("IDO IS " + ft);
		let ft = this.css.map(q => q.log).lastIndexOf("gradient");
	//	// console.log("BLAST IDO IS " + ft + "TR" + this.range);

	
		this.css[ft].rules.push(` 
		${this.preffersId ? id : "." + this.class}{
			background: ${this.globalGradient};
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
		}
		`);
	}

	if (operations.includes("background")){
		//let ft = this.css.map(q => q.range).lastIndexOf(this.range);
		//// console.log("IDO IS " + ft);
		let ft = this.css.map(q => q.log).lastIndexOf("background");
		// console.log("ABLAST IDO IS " + ft + "TR" + this.range);
//alert("Hello" + ft);
//alert(this.class);
		this.css[ft].rules.push(` 
		${this.preffersId ? this.id : "." + this.class}{
			background: green;
		}
		`);

		// console.log("-----Hello-----");
		// console.warn(this.css[ft]);

	}


	if (operations.includes("shadow")){
		let ft = this.css.map(q => q.log).lastIndexOf("shadow");
		
			let str = "";
					let off = 0;
					for (var i = 0; i < this.options.shadow.op.steps; i++){
						off += 3;
						str += `drop-shadow(${off}px ${off}px ${off}px gray) `; 
					}

		// BEWARE OF INDENTATION
		this.css[ft].rules.push(`
		${this.preffersId ? this.id : "." + this.class}{
			filter: ${str};
		 }
					`);
				//	this.res.style.filter = str;
		
	
	}
}

checkQueries();



// console.log("FINAL QUERIES HERE");
// console.log(this.css.map(r => r.rules));
// console.log("::::::::::::::::::::::");

  }*/
setTags(obj){
	//alert("TAGS SET")
	this.openTag = obj.open;
	this.closeTag = obj.close;
	console.log("TAGS SET");
	console.log(obj);

}

  chainReact(queries, id, keep) { // we use this
console.log("0P");
	//this.cssGen(queries, id, this.class, this.class !== undefined); // 02/04/2024 10:43:40 Nice!!!

	this.ap = false;
	this.cta = 0;
	this.once = false;


	// REPLACE WITH DEFAULT RANGE INSIDE FOR LOOP IF NONE IS FOUND 
	// FOR LET QUEYR OF Q
	// if !q.range => q.range = ["0px", "99999px"]
	for (let q of queries){
		if (!q.range){
			// console.log("NOPA");
			q.range = ["0px", "999999px"];
		}
	}

	queries.sort((a, b) => parseInt(a.range[0]) - parseInt(b.range[0]));
  
	// Function to check and log queries based on screen size
	const checkQueries = (qban) => {
		//alert("/P")
	  const screenSize = window.visualViewport.width;  // window.innerWidth window.screen.width window.visualViewport.width
	  let ops = "";
	  let operations = [];
	  let globalQueries = [];

	  this.resCopy = this.res;

	  this.storedQueries = queries.map(el => el.target).filter(el => el != undefined);
  
	  for (const query of queries) {
		this.counterIndex++;

		const [startRange, endRange] = query.range;
		const startSize = parseInt(startRange);
		const endSize = parseInt(endRange);
		let all = true;

		if (query.target){

			all = false;


			for (var i = 0; i < query.target.length; i++){

				if (query.target[i] === id){ // #id is required
				
					all = true;
				}
			}
		} 
  
		if (screenSize >= startSize && screenSize <= endSize && all) { // NEED TO COMMENT ALL
		  operations.push(query.log);
		  globalQueries.push(query);

		  if (query.op && query.op.margin){
			this.useMargin = query.op.margin;
		  }

		} 

	  }


	  if (keep && !keep.includes("background")){
		this.res.style.background = "";
		this.res.style.backgroundColor = "";
	  }
	 
	 
	  this.res.style.textShadow = "";

	  if (keep && !keep.includes("border")){
		this.res.style.border = "";
	  }


	  if (keep && !keep.includes("margin")){
		this.res.style.margin = "";
	  }
	

	  this.res.style['-webkit-text-fill-color'] = '';
	  this.res.style['-webkit-text-stroke-color'] = "";
	  this.res.style['-webkit-text-stroke-width'] = "";
	//  this.res.style['-webkit-background-clip'] = 'unset';
	  this.res.style.filter = "";
	 
	  //if (operations.includes("gradient")){
	 

	//  if (operations.includes("gradient")) {

	
 if (this.options.background){
	console.log(this.options.background);

		 this.res.style.background = this.options.background; 
	  } else {
				//alert("/")
				//console.log("///-Hello-///")
		// this.res.style.background = "black"; always set backgrohnd to shapes dangerous affects divs
	  }
	 // }
	  
	 
	 
	  //"";
	  //}

if (operations.includes("gradient")){
//	alert("IHOIH")
}
	  // NO CONITION, ALWAYS!!!!
	  if (operations.includes("gradient") || operations.includes("shadow")){
			this.res.style.position = "relative";
			//this.res.style.zIndex = -1; 
			// Navigation might go over it give nav higher zIndex
	  } // FIX 23:31:56 10/11/24

	

	  if (operations.includes("blast")){
		
		let gl = globalQueries.filter(x => x.log === "blast")[0].op.color;
		// console.log(gl);

		let w = globalQueries.filter(x => x.log === "blast")[0].op.width ?? "1px";
	

		if (this.getType() === "FlexRowLayoutElement" || this.getType() === "LayoutWrapperElement"){
			// alert("///")
			// this.res.style.opacity = 0.3;
			//alert(`${w}px solid orange`);
			this.res.style.border = `${typeof w === 'number' ? w + 'px' : w} solid orange`;
 this.res.style.display = "inline-block"; // or block
		if (this.getType() === "FlexRowLayoutElement"){
			this.res.style.display = "flex";
		}

    this.res.style.boxSizing = "border-box";
    this.res.style.transformOrigin = "center"; // makes rotations/translations look correct
	this.blastTarget = this.res;
} else {
			if (this.text){

			
			//this.res.textContent = this.text; //"a"
			}
			this.res.style['-webkit-text-fill-color'] = 'transparent';
	
			this.res.style['-webkit-text-stroke-color'] =  gl;//"orange";
			this.res.style['-webkit-text-stroke-width'] = `${w}`;
		//this.res.style.display = "inline-block"; // important for transform
			//alert("HIOH")
		}
	  }

	  if (operations.includes("filter")){
		let w = globalQueries.filter(x => x.log === "filter")[0]
		// console.log(w);
		let filterName = w.op.filter;
			this.res.style.filter = filterName;
	  }

	  if (operations.includes("background")){
		this.res.style.backgroundColor = "green";
	 }

	  if (operations.includes("gradient")){
		// alert(this.getType());
		// not working with blast

		// Children are cleared when setting gradient to wrap and resizing

	    // Set gradient to text
		if (this.getType() !== "LayoutWrapperElement" && this.getType() !== "FlexRowLayoutElement"){
			this.res.style['-webkit-text-fill-color'] = 'transparent';
		}
		//alert(this.globalGradient);

		// globalGradient is set in element "set" method
		this.res.style.background = this.globalGradient;// "linear-gradient(to left, #3498db, #1abc9c)";
		
		
	//	console.log("LGT");
	//	console.log(this.getType());
		if (this.getType() !== "LayoutWrapperElement" && this.getType() !== "FlexRowLayoutElement" ){
		// alert("OJIOJIOIO")
		//alert(this.getType());
			this.res.style['background-clip'] = 'text'; // 19:23:05 05/05/2024 -webkit was a problem here!
		}
	
		

		// In Safari background linear gradient sets background-clip to border-box; this ai automatically put after		
	
	}

	
	  if (operations.includes("shadow")){
const { op } = this.options.shadow;
console.log("OP IS", op);

const steps = op.steps ?? 1;
const colors = op.colors ?? ["gray"];
let movements = op.movements ?? ["3px", "3px"];
const radius = op.radius ?? "3px";

// If movements only contains one value, duplicate it for x and y
if (movements.length === 1) {
  movements = [movements[0], movements[0]];
}

if (this.getType() === "FlexRowLayoutElement" || this.getType() === "LayoutWrapperElement") {
  // use box-shadow for layout containers
  const shadowParts = [];
  for (let i = 0; i < steps; i++) {
    const color = colors[i] ?? colors[0];
    const offsetX = movements[0];
    const offsetY = movements[1];
    shadowParts.push(`${offsetX} ${offsetY} ${radius} ${color}`);
  }
  this.res.style.boxShadow = shadowParts.join(", ");
} else {
  // use drop-shadow for other element types (e.g., text, images)
  const filters = [];
  for (let i = 0; i < steps; i++) {
    const color = colors[i] ?? colors[0];
    const offsetX = movements[0];
    const offsetY = movements[1];
    filters.push(`drop-shadow(${offsetX} ${offsetY} ${radius} ${color})`);
  }
  this.res.style.filter = filters.join(" ");
}




			//if (this.getType() === "FlexRowLayoutElement"){
			//} else {
		/*
				console.log("SOAA");
				console.warn(this.options.shadow);

				let str = "";
				let off = 0;
				for (var i = 0; i < this.options.shadow.op.steps; i++){
					off += 3;
					str += `drop-shadow(${off}px ${off}px ${off}px ${this.options.shadow.op.colors[i] ?? "gray"}) `; 
				}

if (this.getType() === "FlexRowLayoutElement" || this.getType() === "LayoutWrapperElement"){

	let finalFilter = ""
	let offa = 0;
				for (var i = 0; i < this.options.shadow.op.steps; i++){
					offa += 3;
					finalFilter += `${off}px ${off}px ${off}px ${this.options.shadow.op.colors[i] ?? "gray"} `; 
				}
this.res.style.boxShadow = finalFilter;
alert(finalFilter);

//this.res.style.boxShadow = `${off}px ${off}px ${off}px ${this.options.shadow.op.colors[i] ?? "gray"}`; //`${off}px ${off}px ${off}px ${this.options.shadow.op.colors[0] ?? "gray"}`; 
} else {
	this.res.style.filter = str; 
}
				
*/
				
				
	//	}
	  }

	  if (operations.includes("margin")){
		for (var i = 0; i < queries.length; i++){
			if (!queries[i].op){
				continue;
			}
			
			const off  = queries[i].op.offsets;
			
			if (off && this.index !== undefined){
				this.res.style.margin = off[Number(this.index)] + "px";
			}
		}
  }
/*
  if (operations.includes("spana") || operations.includes("span")){


	this.res = this.resCopy;

if (this.options.span){
	let noiseObject;

	if (Array.isArray(this.options.span)){
		noiseObject = this.options.span.filter(a => a.op.name === "span")[0];
	} else {
		noiseObject = this.options.span;
	}

	this.res.textContent = ""; // creating new element not helping
//console.log("OPOOOOO");
//console.log(new Text("A"));
	for (var i = 0; i < noiseObject.op.parts.length; i++){
		let opts = noiseObject.op.parts[i].style;
		let span = new this.constructor(noiseObject.op.parts[i].text).setup({type: "span"}).set(opts).render();
		this.res.appendChild(span);
	}
}



  } else {

let t = new this.constructor(this.prevText).set({}).render();
	if (this.prevText && this.prevText.length > 0 && qban){
this.res.appendChild(t);
	}*/



	if (operations.includes("spana") || operations.includes("span")) {

	const overlay = document.createElement("div");
	overlay.setAttribute("id", "oroa");
Object.assign(overlay.style, {
  position: "absolute",
  inset: "0",
  background: "linear-gradient(90deg, rgb(52,152,219), rgb(26,188,156))",
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  pointerEvents: "none",
});

/*
if (!this.res.querySelector("#oroa") && operations.includes("gradient")){
// Set text content
overlay.textContent = "SWIM FREE";
overlay.style.position = "relative";
this.res.appendChild(overlay);
}*/

		// 🛑 prevent re-creating spans on resize
  if (this.res && this.res.querySelector('span')) return;

  
    this.res = this.resCopy;
    this.res.textContent = ""; // clear current content

    if (this.options.span) {
        let spansArray = Array.isArray(this.options.span)
            ? this.options.span
            : [this.options.span]; // wrap single span in array

        spansArray.forEach(spanObj => {
            if (spanObj.op && spanObj.op.name === "span" && Array.isArray(spanObj.op.parts)) {
                let cursor = 0;
                const fullText = this.prevText || "";

                spanObj.op.parts.forEach(part => {
                    const partText = part.text;
 let opts = part.style || {};
                    // 1️⃣ Append any text before this span
                    if (cursor < fullText.length) {
                        const index = fullText.indexOf(partText, cursor);
                        if (index > cursor) {
                            const plainText = fullText.substring(cursor, index);
                            this.res.appendChild(new this.constructor(plainText).setup({type: "span", id: opts.id, animation: opts.animation}).set({}).render());
                        }
                        cursor = index + partText.length;
                    }

                    // 2️⃣ Append the styled span part
                   
                    let spanEl = new this.constructor(partText).setup({type: "span", id: opts.id, animation: opts.animation}).set(opts).render();
                    this.res.appendChild(spanEl);
                });

                // 3️⃣ Append remaining text after the last span
                if (cursor < fullText.length) {
                    const remainingText = fullText.substring(cursor);
                    this.res.appendChild(new this.constructor(remainingText).setup({type: "span"}).set({}).render());
                }
            }
        });
    }

} else {
    // fallback to full text
    let t = new this.constructor(this.prevText).set({}).render();
    if (this.prevText && this.prevText.length > 0 && qban) {
        this.res.appendChild(t);
    }
}


  

  
	
  if (operations.includes("animation")) {	
//	alert(this.openTag)
	

if (this.options.animation && !this.hasAnimated && !this.options.animation.op.fireAt){

console.warn(this.openTag);
this.hasAnimated = true;
let ass = this.options.animation.op;
//alert(this.openTag);

 window.addEventListener(/*this.openTag*/"sidebar:open", () => {
		
    this.res.animate(ass.keyframesOpen, ass.openOptions);
  });

   window.addEventListener(/*this.closeTag*/ "sidebar:closed", () => {
	
    this.res.animate(ass.keyframesClose, ass.closeOptions);
  });



	this.res.animate(ass.keyframesClose, {
		duration: 0,
		fill: "forwards"
	   });



		//this.res.animate(ass.keyframesOpen, ass.openOptions);
	   if (this.openTag && this.closeTag){
		// alert("ONA" + this.openTag);
		//alert(this.openTag);
		
window.addEventListener(this.openTag, () => {
		this.res.animate(ass.keyframesOpen, ass.openOptions);
	});
// "sidebar:opened" "sidebar:closed"
	window.addEventListener(this.closeTag, () => {
		this.res.animate(ass.keyframesClose, ass.closeOptions);
	});
	   }
	

}

// 18:42:30 it works! 02/02/2025
// Thanks ChatGPT!
	  if (this.options.animation && this.options.animation.op.fireAt && this.options.animation.op.fireAt.endsWith("px")) {

		  let ass = this.options.animation.op;

		  this.res.animate(ass.keyframesClose, {
			  duration: 0,
			  fill: "forwards"
		  });

		  const scrollHandler = () => {
			  if (window.scrollY > parseFloat(ass.fireAt)) {
				  this.res.animate(ass.keyframesOpen, ass.openOptions);
				  window.removeEventListener("scroll", scrollHandler);
			  }
		  };

		  window.addEventListener("scroll", scrollHandler);

	  } 

	  if (this.options.animation && this.options.animation.op.fireAt === "inview") {
  let ass = this.options.animation.op;
  this.res.animate(ass.keyframesClose, { duration: 0, fill: "forwards" });

  let hasOpened = false;

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !hasOpened) {
        hasOpened = true;
        this.res.animate(ass.keyframesOpen, ass.openOptions);
        observer.disconnect();
      }
    });
  });

  observer.observe(this.res);
}
/*
if (!this.openedElements.get(this.res)) {
  const ass = this.options.animation.op;

this.res.querySelectorAll('span').forEach(span => {
  if (!span._hasOpened) {
    span.animate(ass.keyframesClose, { duration: 0, fill: "forwards" });

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !span._hasOpened) {
          span._hasOpened = true;
          span.animate(ass.keyframesOpen, ass.openOptions);
          observer.disconnect();
        }
      });
    });

    observer.observe(span);
  }
});
}*/




/*
	  if (this.options.animation && this.options.animation.op.fireAt && this.options.animation.op.fireAt === "inview") {

		let ass = this.options.animation.op;

		this.res.animate(ass.keyframesClose, {
			duration: 0,
			fill: "forwards"
		});


	  const observer = new IntersectionObserver((entries, observer) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				// console.log("Element is in view!");
				this.res.animate(ass.keyframesOpen, ass.openOptions);
				// Perform your action here
				observer.disconnect(); // Stop observing if you only want it to fire once
			}
		});
	});

		// Start observing the element
		observer.observe(this.res);
}*/
	
		
	}

	}
  
	// Add an event listener to check queries on window resize
	
	if (!this.options.animation /*&& this.getType() !== "LayoutWrapperElement"*/){
	
	window.addEventListener('resize', () => checkQueries());
	}
	
	checkQueries();
  }
  
  //--------- END OF INDEPENDENT
  
  reactOnTransform = (obj) => {
console.log("LOBJO IS");
//alert("///"); // UL DOES NOT REACH THIS DESPITE SAME SYNTAX
console.log("REPO");
console.log(this.res);

console.log(obj); // Why obj.op.transform not working for link
//console.log(obj.op.transform); // I need obj.op.transform
// 





	if (obj.transform || (obj.op /*&& obj.op.transform*/)){
		
		console.log("SIMPLIFIED");

	console.log(obj.transform);
	console.log(obj.op);






		let transform = obj.op;//transform; 

		if (!obj.transform ){ // 21:48:05 Nice!!! 30/03/25
			transform = obj.op;
		}

		if (!transform.duration){
			transform.duration = "3s-ease-in-out";
		}


		console.log("ENTERING");
		console.log(transform);
	
		//  {static: true, keep: true, values: Array(4), duration: '3s-ease-in-out'
		// SIMPLE
		
		// COMPLEX
		// {static: true, keep: true, values: Array(4), duration: '3s-ease-in-out'}
		
		
		this.setDefault = (value, defaultValue = "0px") => {
			return value.length === 0 ? defaultValue + " " : value;
		}

		const convertRotateString = (input)  => {
			const match = input.match(/rotate\(([^)]+)\)/);
			if (!match) return input; // Return unchanged if no match found
		
			const values = match[1].split(',').map(v => v.trim());
		
			if (values.length === 1) {
				return `rotate(${values[0]})`;
			} else if (values.length === 2) {
				return `rotateX(${values[0]}) rotateY(${values[1]})`;
			} else if (values.length === 3) {
				return `rotateX(${values[0]}) rotateY(${values[1]}) rotate(${values[2]})`;
			}
		
			return input; // Return unchanged if more than 3 values
		}
		
	
	const perform = () => {
		
	let translateX = '';
	let translateY = '';
	let translateZ = '';
	let scale = '';
	let skew = '';
	let rotate = '';
	let perspective = '';
	let matrix = '';
	let opacity = '';

	console.log("ERRA - still nested");
	// There is still nested transform object
	console.log(transform);

	// Check if the transform values array is empty
	if (transform.values.length === 0) { 
		return; // If the array is empty, exit the function
	}

	console.warn(transform);

	// Loop through the transform values and extract the needed ones
	transform.values.forEach(value => {
		if (value.startsWith('tx:')) {
			translateX = value.replace('tx:', ''); // Extract -20px from ty:-20px
		} if (value.startsWith('ty:')) {
			translateY = value.replace('ty:', ''); // Extract -20px from ty:-20px
		} if (value.startsWith('tz:')) {
			translateZ = value.replace('tz:', ''); // Extract -20px from ty:-20px
		} else if (value.startsWith('scale(')) {
			scale = value; // Extract scale(3) or any other scale
		} else if (value.startsWith("skew(")) {
			skew = value;
		}  else if (value.startsWith("rotate(")) {
			rotate = convertRotateString(value);
		} else if (value.startsWith("perspective(")) {
			perspective = value;
		} else if (value.startsWith("matrix(")) {
			matrix = value;
		} else if (value.startsWith("opacity:")) {
			opacity = value.replace('opacity:', '');
			//alert(opacity);
		}
	});

	

	translateX = this.setDefault(translateX);
	translateY = this.setDefault(translateY);
	translateZ = this.setDefault(translateZ);

	// Apply the transform to the element, only if translateY or scale is present
	let transformValue = '';
	// PROBLEM HERE
	// transformValue += `translate(30px, 0px, 0px)`; // CSS translate has only two vals  (need trans3D for 3)
	
	
	if (translateY != "0px" && translateX != "0px" && translateZ != "0px") {
		transformValue += `translate3d(${translateX}, ${translateY}, ${translateZ})`;
	} else if (translateY != "0px" || translateX != "0px") {
		transformValue += `translate(${translateX}, ${translateY})`
	};


	if (scale) transformValue += ` ${scale}`;
	if (rotate) transformValue += ` ${rotate}`;
	if (skew) transformValue += ` ${skew}`;
	if (perspective) transformValue += ` ${perspective}`;
	if (matrix) transformValue += ` ${matrix}`;

	if (transformValue) {
		// alert("/") 

		if (obj.op.duration){ // transform 3s in and out takes 8 secs instead of 6....
			let newStr = obj.op.duration.replace(/^(\d+)(s)-/, (_, n, s) => n / 2 + s + " "); 
//alert(newStr);

			//newStr = "6s";
			let trans = `transform ${newStr}, opacity  ${newStr}`; // Reset transition
			this.res.style.transition = trans;
		
		} else {
			
			this.res.style.transition = "transform 3s ease-in-out, opacity 3s ease-in-out"; // Reset transition
		}

		if (obj.op.static){
			this.res.style.transition = "";
		}

		// 17:37:15 a comma was missing
		//this.res.style.transform = transformValue;
		(this.blastTarget || this.res).style.transform = transformValue;
		this.res.style.opacity = opacity;
	} else {
		alert("OPE")
	}
	}


	if (transform.on){
		this.res.addEventListener(transform.on, () => {
			if (transform.delay) {
				setTimeout(() => {
					perform();
				}, transform.delay);

			} else {
				perform()
			}
		});
		
	} else {
		
		window.addEventListener("load", () => {
			if (transform.delay) {

				setTimeout(() => {
					perform();
				}, transform.delay);
			} else {
				perform();
			}
		})
		
		
	}


	const reset = () => {
		let resetTransformValue = '';
console.log("RESET");
console.log(transform);

		transform.values.forEach(value => {
			if (value.startsWith('tx:')) {
				resetTransformValue += "translateX(0) ";
			} else if (value.startsWith('ty:')) {
				resetTransformValue += "translateY(0) ";
			} else if (value.startsWith('tz:')) {
				resetTransformValue += "translateZ(0) ";
			} else if (value.startsWith('scale(')) {
				resetTransformValue += "scale(1) ";
			} else if (value.startsWith('skew(')) {
				resetTransformValue += "skew(0, 0) "; // Assuming 2D skew reset
			} else if (value.startsWith('rotate(')) {
				resetTransformValue += "rotate(0) ";
			} else if (value.startsWith('perspective(')) {
				resetTransformValue += "perspective(0) "; // Assuming 0 for perspective
			} else if (value.startsWith('matrix(')) {
				resetTransformValue += "matrix(1, 0, 0, 1, 0, 0) "; // Reset to identity matrix
			}

			this.res.style.opacity = "1";


		});
	
		// Apply reset transform if any values were provided
		if (resetTransformValue) {
		//	this.res.style.transition = "transform 0.5s ease-in-out"; // Reset transition
			this.res.style.transform = resetTransformValue.trim(); // Remove trailing space
		}
	}


if (transform.on){

	this.res.addEventListener("mouseout", () => {
		if (!transform.keep){
			reset();
		}
		
	});
} else {
	let duration = parseFloat(transform.duration) * 1000;
	let resetAfter = transform.closeAfter ? transform.closeAfter : 0;

	setTimeout(() => {
		if (!transform.keep) {
			reset();
		}
	}, duration / 2 + resetAfter); // 15:16:26 Nice!!!
}

	if (transform.hardCSS){
		// alert("PI")
		this.res.style.transform = transform.hardCSS;
	}
	
	} else {
		alert("THIS FIRE WITH GRADIENT (invalid block");
		console.log("INVALID BLOCKA");
		console.log(obj);
	}

	}



maxWidth(w){
    this.res.style.maxWidth = w;
    return this;
}

removeQuotesFromFirstWord(jsonString) {
	const modifiedJSON = jsonString.replace(/"([^"]+)":/g, '$1:');
	return modifiedJSON;
  }
  

arrayMargin(arr, value) { // 224857 redefined earlier

	// // console.log(arr);
	if (arr.includes("left")){
		this.res.style.marginLeft = value;
	}
	
	if (arr.includes("right")){
		this.res.style.marginRight = value;
	}
	
	if (arr.includes("top")){
		this.res.style.marginTop = value;
	}
	
	if (arr.includes("bottom")){
		this.res.style.marginBottom = value;
	}

	if (arr.includes("all")){
		this.res.style.margin = value;
	}

	if (!value){
		this.res.style.marginBottom = arr;
	}
	
	return this;
}
/*

    navBarExpand(){
        this.res.style.backgroundColor = "green";
        this.res.animate([
            {transform: "scaleY(3.0)"}
        ], {
            
				
                duration: 2000,
                iterations: 1,
                 fill: "both"
                
        })//.play();

        return this;
    }





    
	scrollFade(duration, direction){
		this.res.style.visibility = "hidden";
		this.faden(duration, direction, "scroll");
		return this;
	}
    
    
    
    
    expand(obj){
        
        
        
        if (this.state.isExpanded === false){
            
        
        if (obj.on === "click"){
            this.res.addEventListener("click", () => {
               this.innerExpand(obj); 
                // this.moveUp(obj);
            });
        } else {
            this.innerExpand(obj);
           
        }
        
        } else {
            
            this.innerExpandBack(obj);
            
            
        }
        
        this.state.isExpanded = !this.state.isExpanded;
        
        // // // console.log("IS EXPANDED: " + this.state.isExpanded);
        return this;
    }*/
    
     /*
    move(obj){
        
        if (obj.on === "click"){
            this.res.addEventListener("click", () => {
               this.moveUpa(obj); 
                // this.moveUp(obj);
            });
        } else {
                if (obj.direction === "up"){
                    this.moveUpa(obj);
                }
            
            if (obj.direction === "down"){
                    this.moveDowna(obj);
                }
          //  }
            
            
             this.state.isMovedUp = !this.state.isMovedUp;
            
                if (obj.direction === "left"){
                    this.moveLeft(obj);
                }
        }
        
        return this;
    }
    
    
    
    
     moveLeft(obj){
         this.res.animate([
        {transform: `translateX(0px)`},   
         {transform: `translateX(-${obj.distance})`},
         
		],{
				
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		}).play();
        
        return this;
    }
    
   
    moveUpa(obj){
        if (this.state.isMovedUp === false){
            
        this.res.animate([
        {transform: `translateX(0px)`}, 
         {transform: `translateY(-${obj.distance})`},
		],{	
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		}).play();
        
        } else {
            
        this.res.animate([
        {transform: `translateX(0px)`}, 
         {transform: `translateY(${obj.distance})`},
		],{	
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		}).play();
            
        }
        return this;
    }
    
    
     moveDowna(obj){
        if (this.state.isMovedDown === false){
            
        this.res.animate([
        {transform: `translateX(0px)`}, 
         {transform: `translateY(${obj.distance})`},
		],{	
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		}).play();
        
        } else {
            
        this.res.animate([
        {transform: `translateX(0px)`}, 
         {transform: `translateY(-${obj.distance})`},
		],{	
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		}).play();
            
        }
        return this;
    }
    
    
    
    moveUpaBack(obj){
         this.res.animate([
        {transform: `translateX(0px)`},
		],{
				
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		}).play();
        
        
        return this;
    }
    
    

    innerExpandBack(obj){
         this.res.animate([
       
         
         {width: this.prevWidth,
          height: this.prevHeight},
         
       //  {width: "100px", height: "100px"}
		],{
				
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		});
    }
    
    innerExpand(obj){
        this.prevWidth = this.res.style.width;
        this.prevHeight = this.res.style.height;
            
     this.res.animate([
        {width: this.prevWidth,
        height: this.prevHeight},
         
         {width: obj.width ?? this.prevWidth,
          height: obj.height ?? this.prevHeight},
		],{
				
		duration: 900,
		iterations: obj.iterations,
         fill: "both"
		});
        
        return this;
        
        }
        

	fade(obj){
		
		this.res.style.visibility = "hidden";
		this.faden(obj.duration, obj.from, "load");

        if (obj.finalOpacity){
this.finalOpacity = obj.finalOpacity;
        }
		return this;
	}
	
	faden(duration, direction, event){
		this.res.style.visibility = "hidden";
		this.scrolled = false;	
	
		 window.addEventListener(event, () => {
			this.res.style.visibility = "visible";
			 var height = window.innerHeight;
			   var top = this.res.getBoundingClientRect().top;
            if ((top - height <= 0) || (event == "load")) {
				
			 if (this.scrolled == false){
				 
	if (direction == "left"){
					  
		this.res.animate([
			{transform: "translateX(-30px)"},
			{transform: "translateX(0px)"},
		],{
				
		duration: duration,
		iterations: 1
		});
	}
				 
	if (direction == "right"){
					  
		this.res.animate([
			{transform: "translateX(30px)"},
			{transform: "translateX(0px)"},
		],{
				
		duration: duration,
		iterations: 1
		});
	}
				 
				 
	if (direction == "top"){  
		this.res.animate([
			{transform: "translateY(-30px)"},
			{transform: "translateY(0px)"},
		],{
				
		duration: duration,
		iterations: 1
		});
	}
				 
	
	if (direction == "bottom"){
		this.res.animate([
			{transform: "translateY(30px)"},
			{transform: "translateY(0px)"},
		],{
				
		duration: duration,
		iterations: 1
		});
	}
				 
		this.res.animate([
			{opacity: "0.0"},
			{opacity: "1.0"}	
		],{
		duration: duration,
		iterations: 1
		});
				 
		this.scrolled = true;	 
			 }	
			} 
		 });
		return this;
	}*/
} // 2600-1870

export { Animator };
